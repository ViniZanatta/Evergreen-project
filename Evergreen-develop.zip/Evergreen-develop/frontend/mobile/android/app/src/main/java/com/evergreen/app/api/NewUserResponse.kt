package com.evergreen.app.api

data class NewUserResponse (val user:User,val message:String,val success:Boolean)