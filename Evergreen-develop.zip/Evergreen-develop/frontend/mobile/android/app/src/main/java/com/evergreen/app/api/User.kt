package com.evergreen.app.api

data class User (
    val name:String,
    val email:String,
    val birthday:String,
    val gender:String,
    val cellPhone:String,
    val password:String
        )