package com.evergreen.app.api

data class LoginResponse (val success:Boolean, val jwt:String)