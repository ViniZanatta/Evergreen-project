package br.com.evergreenapi.Domain;

public enum Gender {
    Female,
    Male,
}
