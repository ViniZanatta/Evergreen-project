package br.com.evergreenapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvergreenApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
